import React from "react";
import Navbar from "../components/slider/Navbar";
import Sidenav from "../components/slider/Sidenav";
import { Box } from "@mui/material";
const Layout = ({ children }: any) => {
  return (
    <>
      <Box sx={{ display: "flex" }}>
        <Sidenav />
        <Box
          component="main"
          sx={{
            flexGrow: 1,
            p: 3,
            mt: 8,
            background: "#FAFAFB",
            height: "auto",
          }}
        >
          <Navbar />
          <div className="main-content">{children}</div>
        </Box>
      </Box>
    </>
  );
};

export default Layout;
