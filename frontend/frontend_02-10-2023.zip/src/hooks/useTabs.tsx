import { Tabs as MantineTabs } from "@mantine/core";
import { getString } from "@/helpers";
import { useState } from "react";

const List = MantineTabs.List;
const Tab = MantineTabs.Tab;
const useTabs = () => {
  const [activeTab, setActiveTab] = useState<string | null>(null);

  const Tabs = ({
    tabs,
    filterDataWithActiveTab,
  }: {
    tabs: string[];
    filterDataWithActiveTab: (e: string) => void;
  }) => {
    const filterStatusRecords = (
      e: React.SyntheticEvent<HTMLButtonElement>,
      tab?: string
    ) => {
      e.preventDefault();

      if (tab) {
        filterDataWithActiveTab(tab);
        setActiveTab(tab);
      }

      return;
    };

    return (
      <MantineTabs defaultValue={activeTab ?? tabs[0]}>
        <List>
          {tabs &&
            tabs?.map((tab, i) => (
              <Tab
                value={tab}
                key={i}
                onClick={(e) => filterStatusRecords(e, tab)}
              >
                {getString(tab)}
              </Tab>
            ))}
        </List>
      </MantineTabs>
    );
  };

  return { Tabs };
};

export default useTabs;
